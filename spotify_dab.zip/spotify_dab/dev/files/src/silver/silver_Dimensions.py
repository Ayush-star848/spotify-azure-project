# Databricks notebook source
# MAGIC %md
# MAGIC ### DimUser ###
# MAGIC

# COMMAND ----------

from pyspark.sql.functions import *
from pyspark.sql.types import *
import os
import sys
project_path = os.path.join(os.getcwd(), '..','..') 
sys.path.append(project_path)

from utils.transformations import reusable

# COMMAND ----------

# MAGIC %md
# MAGIC ### AutoLoader ###

# COMMAND ----------

df_user = spark.readStream.format("cloudFiles")\
            .option("cloudFiles.format","parquet")\
            .option("cloudFiles.schemaLocation","abfss://silver@ayushstoragezureproj.dfs.core.windows.net/DimUser/checkpoint")\
            .option("schemaEvolutionMode","addNewColumns")\
            .load("abfss://bronze@ayushstoragezureproj.dfs.core.windows.net/DimUser")

# COMMAND ----------

# display(df_user,
#         outputMode="append",
#     checkpointLocation="abfss://silver@ayushstoragezureproj.dfs.core.windows.net/DimUser/checkpoint/display_cell7_v2")

# COMMAND ----------

# /Workspace/Users/gupta.ayush.04050803_gmail.com#ext#@guptaayush04050803gmail.onmicrosoft.com/spotify_dab/utils/transformations.py
# from spotify_dab.utils.transformations import var_ayush


# COMMAND ----------

df_user_obj = reusable()


# COMMAND ----------

# df_user = df_user_obj.dropColumns(df_user,['rescued_data'])
# df_user = df_user.dropDuplicates(['user_id'])
# display(df_user, checkpointLocation="abfss://silver@ayushstoragezureproj.dfs.core.windows.net/DimUser/checkpoint/display_cell8")

# COMMAND ----------

df_user.writeStream.format("delta") \
    .outputMode("append")  \
    .option("checkpointLocation","abfss://silver@ayushstoragezureproj.dfs.core.windows.net/DimUser/checkpoint") \
    .trigger(once=True)\
     .toTable("spotify_cata.silver.DimUser")  
    

# COMMAND ----------

df_user = df_user.withColumn("user_name", upper(col("user_name")))
display(df_user, checkpointLocation="abfss://silver@ayushstoragezureproj.dfs.core.windows.net/DimUser/checkpoint/display_cell8")

# COMMAND ----------

print(df_user.isStreaming)

# COMMAND ----------

# MAGIC %md
# MAGIC ### DimArtist ###
# MAGIC

# COMMAND ----------

df_art = spark.readStream.format("cloudFiles") \
    .option("cloudFiles.format","parquet") \
    .option("cloudFiles.schemaLocation","abfss://silver@ayushstoragezureproj.dfs.core.windows.net/DimArt/schema") \
    .option("cloudFiles.schemaEvolutionMode","addNewColumns") \
    .load("abfss://bronze@ayushstoragezureproj.dfs.core.windows.net/DimArtist") 

# COMMAND ----------

display(df_art, checkpointLocation="abfss://silver@ayushstoragezureproj.dfs.core.windows.net/DimArtist/checkpoint/display_cell13")


# COMMAND ----------

df_art_obj = reusable()
df_art = df_art_obj.dropColumns(df_art,['rescued_data'])
df_art = df_art.dropDuplicates(['artist_id'])
display(df_art,checkpointLocation="abfss://silver@ayushstoragezureproj.dfs.core.windows.net/DimArtist/checkpoint/display_cell15")

# COMMAND ----------

df_art.writeStream.format("delta") \
    .outputMode("append")  \
    .option("checkpointLocation","abfss://silver@ayushstoragezureproj.dfs.core.windows.net/DimArt/checkpoint") \
    .trigger(once=True)\
     .option("path","abfss://silver@ayushstoragezureproj.dfs.core.windows.net/DimArt")\
     .toTable("spotify_cata.silver.DimArtist") 

# COMMAND ----------

# MAGIC %md
# MAGIC ### DimTrack ###

# COMMAND ----------

df_track = spark.readStream.format("cloudFiles") \
    .option("cloudFiles.format","parquet") \
    .option("cloudFiles.schemaLocation","abfss://silver@ayushstoragezureproj.dfs.core.windows.net/DimTrack/schema") \
    .option("cloudFiles.schemaEvolutionMode","addNewColumns") \
    .load("abfss://bronze@ayushstoragezureproj.dfs.core.windows.net/DimTrack") 

# COMMAND ----------

display(df_track, checkpointLocation="abfss://silver@ayushstoragezureproj.dfs.core.windows.net/DimTrack/checkpoint/display_cell18")

# COMMAND ----------

df_track = df_track.withColumn("durationFlag",when(col('duration_sec')<150,'short').when(col('duration_sec')>300,'long').otherwise('medium') )




# COMMAND ----------

# display(df_track,checkpointLocation="abfss://silver@ayushstoragezureproj.dfs.core.windows.net/DimTrack/checkpoint/display_cell20")


# COMMAND ----------

df_track = df_track.withColumn("track_name",regexp_replace(col('track_name'),'-','') )

# COMMAND ----------

display(df_track,checkpointLocation="abfss://silver@ayushstoragezureproj.dfs.core.windows.net/DimTrack/checkpoint/display_cell22")

# COMMAND ----------

df_track = reusable().dropColumns(df_track,['_rescued_data'])

# COMMAND ----------

display(df_track,checkpointLocation="abfss://silver@ayushstoragezureproj.dfs.core.windows.net/DimTrack/checkpoint/display_cell24")

# COMMAND ----------

df_track.writeStream \
    .format("delta") \
    .outputMode("append") \
    .option("checkpointLocation",
        "abfss://silver@ayushstoragezureproj.dfs.core.windows.net/DimTrack/checkpoint") \
    .trigger(once=True) \
    .toTable("spotify_cata.silver.DimTrack")

# COMMAND ----------

# MAGIC %md
# MAGIC ### DimDate ###
# MAGIC

# COMMAND ----------

df_date = spark.readStream.format("cloudFiles") \
    .option("cloudFiles.format","parquet") \
    .option("cloudFiles.schemaLocation","abfss://silver@ayushstoragezureproj.dfs.core.windows.net/DimDate/schema") \
    .option("cloudFiles.schemaEvolutionMode","addNewColumns") \
    .load("abfss://bronze@ayushstoragezureproj.dfs.core.windows.net/DimDate") 

# COMMAND ----------

df_date = reusable().dropColumns(df_date,['_rescued_data'])

# COMMAND ----------

df_date.writeStream \
    .format("delta") \
    .outputMode("append") \
    .option("checkpointLocation",
        "abfss://silver@ayushstoragezureproj.dfs.core.windows.net/DimDate/checkpoint") \
    .trigger(once=True) \
    .toTable("spotify_cata.silver.DimDate")

# COMMAND ----------

# MAGIC %md
# MAGIC ### FactStream ###

# COMMAND ----------

df_fact = spark.readStream.format("cloudFiles") \
    .option("cloudFiles.format","parquet") \
    .option("cloudFiles.schemaLocation","abfss://silver@ayushstoragezureproj.dfs.core.windows.net/FactStream/schema") \
    .option("cloudFiles.schemaEvolutionMode","addNewColumns") \
    .load("abfss://bronze@ayushstoragezureproj.dfs.core.windows.net/FactStream") 

# COMMAND ----------

display(df_fact,checkpointLocation="abfss://silver@ayushstoragezureproj.dfs.core.windows.net/FactStream/checkpoint/display_cell30")

# COMMAND ----------

df_fact = reusable().dropColumns(df_fact,['_rescued_data'])


# COMMAND ----------

df_fact.writeStream \
    .format("delta") \
    .outputMode("append") \
    .option("checkpointLocation",
        "abfss://silver@ayushstoragezureproj.dfs.core.windows.net/FactStream/checkpoint") \
    .trigger(once=True) \
    .option("path","abfss://silver@ayushstoragezureproj.dfs.core.windows.net/FactStream") \
    .toTable("spotify_cata.silver.FactStream")

# COMMAND ----------

# MAGIC %md
# MAGIC ### debuging###

# COMMAND ----------

# MAGIC %sql
# MAGIC DROP TABLE spotify_cata.silver.dimartist;

# COMMAND ----------

df_art.writeStream \
    .format("delta") \
    .outputMode("append") \
    .option(
        "checkpointLocation",
        "abfss://silver@ayushstoragezureproj.dfs.core.windows.net/DimArtist/checkpoint"
    ) \
    .trigger(once=True) \
    .toTable("spotify_cata.silver.DimArtist")

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT * 
# MAGIC FROM spotify_cata.silver.dimartist
# MAGIC LIMIT 10;
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT * FROM spotify_cata.gold.dimtrack
# MAGIC WHERE `__END_AT` IS NOT NULL
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT * FROM spotify_cata.gold.dimtrack
# MAGIC WHERE track_id in (46,5)

# COMMAND ----------


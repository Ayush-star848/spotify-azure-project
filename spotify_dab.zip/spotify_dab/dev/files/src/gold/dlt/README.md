# New Pipeline 2026-03-12 13:11

This folder defines all source code for the 'New Pipeline 2026-03-12 13:11' pipeline:

- `explorations`: Ad-hoc notebooks used to explore the data processed by this pipeline.
- `transformations`: All dataset definitions and transformations.
- `utilities`: Utility functions and Python modules used in this pipeline.

## Getting Started

To get started, go to the `transformations` folder -- most of the relevant source code lives there:

* By convention, every dataset under `transformations` is in a separate file.
* Take a look at the sample under "sample_users_mar_12_1311.py" to get familiar with the syntax.
  Read more about the syntax at https://learn.microsoft.com/azure/databricks/ldp/developer/python-ref.
* Use `Run file` to run and preview a single transformation.
* Use `Run pipeline` to run _all_ transformations in the entire pipeline.
* Use `+ Add` in the file browser to add a new data set definition.
* Use `Schedule` to run the pipeline on a schedule!

For more tutorials and reference material, see https://learn.microsoft.com/azure/databricks/ldp.